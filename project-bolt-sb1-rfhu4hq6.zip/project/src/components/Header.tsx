import { useState, useEffect } from 'react';
import { Sun, Moon, Menu } from 'lucide-react';
import { useWeatherStore } from '../store/weatherStore';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { currentWeather } = useWeatherStore();
  
  const isDay = currentWeather?.isDay || true;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`sticky top-0 z-20 transition-all duration-500 ${
        isScrolled 
          ? 'backdrop-blur-md bg-black/20'
          : 'bg-transparent'
      }`}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        <div className="flex items-center">
          <div 
            className="mr-3 flex h-10 w-10 items-center justify-center rounded-full bg-white/10 backdrop-blur-md"
          >
            {isDay ? 
              <Sun className="h-6 w-6 text-yellow-300" /> : 
              <Moon className="h-6 w-6 text-blue-200" />
            }
          </div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-pink-200">
              Clima
            </span>
            <span className="ml-1 opacity-60">Viz</span>
          </h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <nav className="hidden md:block">
            <ul className="flex space-x-6">
              {['Dashboard', 'Maps', 'Forecasts', 'Settings'].map((item) => (
                <li key={item}>
                  <button className="text-sm font-medium text-white/70 transition-colors hover:text-white">
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
          
          <button 
            onClick={() => setMenuOpen(!menuOpen)}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 backdrop-blur-md md:hidden"
          >
            <Menu className="h-5 w-5 text-white" />
          </button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {menuOpen && (
        <div className="absolute left-0 right-0 top-16 z-20 bg-black/30 backdrop-blur-lg md:hidden">
          <nav className="px-4 py-4">
            <ul className="space-y-3">
              {['Dashboard', 'Maps', 'Forecasts', 'Settings'].map((item) => (
                <li key={item}>
                  <button 
                    className="w-full py-2 text-left text-white/70 transition-colors hover:text-white"
                    onClick={() => setMenuOpen(false)}
                  >
                    {item}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;