import { useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useWeatherStore } from '../store/weatherStore';
import { formatHour, formatDay } from '../utils/dateUtils';

const Forecast = () => {
  const { forecast } = useWeatherStore();
  const [activeTab, setActiveTab] = useState('hourly');
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  
  const handleScroll = (direction: 'left' | 'right') => {
    if (!scrollContainerRef.current) return;
    
    const container = scrollContainerRef.current;
    const scrollDistance = container.clientWidth * 0.75;
    
    if (direction === 'left') {
      container.scrollBy({ left: -scrollDistance, behavior: 'smooth' });
    } else {
      container.scrollBy({ left: scrollDistance, behavior: 'smooth' });
    }
  };
  
  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="mx-auto max-w-3xl"
    >
      <div className="mb-3 flex items-center justify-between">
        <div className="flex space-x-3">
          <TabButton 
            active={activeTab === 'hourly'} 
            onClick={() => setActiveTab('hourly')}
          >
            Hoje
          </TabButton>
          <TabButton 
            active={activeTab === 'daily'} 
            onClick={() => setActiveTab('daily')}
          >
            Próximos dias
          </TabButton>
        </div>
      </div>
      
      <div className="relative">
        <button 
          onClick={() => handleScroll('left')}
          className="absolute -left-4 top-1/2 z-10 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-black/20 backdrop-blur-sm"
          aria-label="Scroll left"
        >
          <ChevronLeft className="h-5 w-5 text-white" />
        </button>
        
        <div 
          ref={scrollContainerRef}
          className="hide-scrollbar flex overflow-x-auto py-2"
        >
          <div className="flex space-x-3 px-2">
            {activeTab === 'hourly' ? (
              // Hourly forecast
              forecast?.hourly.map((hour, idx) => (
                <HourlyCard 
                  key={idx}
                  time={formatHour(hour.time)}
                  temp={Math.round(hour.temp)}
                  icon={hour.icon}
                  isNow={idx === 0}
                />
              ))
            ) : (
              // Daily forecast
              forecast?.daily.map((day, idx) => (
                <DailyCard 
                  key={idx}
                  day={formatDay(day.date)}
                  icon={day.icon}
                  high={Math.round(day.maxTemp)}
                  low={Math.round(day.minTemp)}
                  condition={day.condition}
                  isToday={idx === 0}
                />
              ))
            )}
          </div>
        </div>
        
        <button 
          onClick={() => handleScroll('right')}
          className="absolute -right-4 top-1/2 z-10 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-full bg-black/20 backdrop-blur-sm"
          aria-label="Scroll right"
        >
          <ChevronRight className="h-5 w-5 text-white" />
        </button>
        
        {/* Gradient fades */}
        <div className="pointer-events-none absolute left-0 top-0 h-full w-8 bg-gradient-to-r from-indigo-900/50 to-transparent"></div>
        <div className="pointer-events-none absolute right-0 top-0 h-full w-8 bg-gradient-to-l from-indigo-900/50 to-transparent"></div>
      </div>
    </motion.section>
  );
};

type TabButtonProps = {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
};

const TabButton = ({ active, onClick, children }: TabButtonProps) => (
  <button
    onClick={onClick}
    className={`relative rounded-full px-4 py-1.5 text-sm font-medium transition-all duration-300 ${
      active 
        ? 'bg-white/10 text-white backdrop-blur-sm' 
        : 'text-white/60 hover:text-white'
    }`}
  >
    {children}
    {active && (
      <motion.div
        layoutId="activeForecastTab"
        className="absolute inset-0 rounded-full bg-white/10 backdrop-blur-sm"
        style={{ zIndex: -1 }}
        transition={{ duration: 0.3 }}
      />
    )}
  </button>
);

type HourlyCardProps = {
  time: string;
  temp: number;
  icon: string;
  isNow?: boolean;
};

const HourlyCard = ({ time, temp, icon, isNow = false }: HourlyCardProps) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4 }}
    className={`flex min-w-20 flex-col items-center rounded-xl p-3 ${
      isNow 
        ? 'bg-white/15 backdrop-blur-md' 
        : 'bg-white/5 backdrop-blur-sm hover:bg-white/10'
    }`}
  >
    <span className={`text-xs font-medium ${isNow ? 'text-white' : 'text-white/70'}`}>
      {isNow ? 'Agora' : time}
    </span>
    
    <img 
      src={`/weather-icons/${icon}.svg`} 
      alt="Weather condition"
      className="my-2 h-8 w-8"
    />
    
    <span className="text-base font-semibold text-white">{temp}°</span>
  </motion.div>
);

type DailyCardProps = {
  day: string;
  icon: string;
  high: number;
  low: number;
  condition: string;
  isToday?: boolean;
};

const DailyCard = ({ day, icon, high, low, condition, isToday = false }: DailyCardProps) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4 }}
    className={`flex min-w-32 flex-col rounded-xl px-4 py-3 ${
      isToday 
        ? 'bg-white/15 backdrop-blur-md' 
        : 'bg-white/5 backdrop-blur-sm hover:bg-white/10'
    }`}
  >
    <span className={`text-sm font-medium ${isToday ? 'text-white' : 'text-white/70'}`}>
      {isToday ? 'Hoje' : day}
    </span>
    
    <div className="my-2 flex items-center">
      <img 
        src={`/weather-icons/${icon}.svg`} 
        alt={condition}
        className="mr-2 h-10 w-10"
      />
      <span className="text-xs text-white/70">{condition}</span>
    </div>
    
    <div className="flex items-center justify-between">
      <span className="text-base font-semibold text-white">{high}°</span>
      <span className="text-sm text-white/60">{low}°</span>
    </div>
  </motion.div>
);

export default Forecast;