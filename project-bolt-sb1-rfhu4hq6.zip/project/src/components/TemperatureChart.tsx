import { useMemo } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

const TemperatureChart = () => {
  const data = useMemo(() => {
    const hours = Array.from({ length: 19 }, (_, i) => i + 6); // 6:00 to 00:00
    return hours.map(hour => {
      let temp;
      if (hour < 10) {
        temp = 18 + (hour - 6) * 0.5;
      } else if (hour < 15) {
        temp = 20 + (hour - 10) * 1.6;
      } else {
        temp = 28 - (hour - 15) * 1.2;
      }
      
      return {
        time: `${hour.toString().padStart(2, '0')}:00`,
        temperature: Math.round(temp * 10) / 10
      };
    });
  }, []);

  return (
    <div className="h-[300px] w-full">
      <div className="mb-4">
        <h3 className="text-lg font-medium text-white">
          Temperaturas ao longo do dia
        </h3>
        <div className="mt-1 flex space-x-4 text-sm text-white/70">
          <div>Mínima: <span className="text-blue-300">18°C</span></div>
          <div>Máxima: <span className="text-red-300">28°C</span></div>
        </div>
      </div>
      
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id="temperatureGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#fff" stopOpacity={0.2}/>
              <stop offset="95%" stopColor="#fff" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" vertical={false} />
          <XAxis
            dataKey="time"
            tickLine={false}
            tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
            stroke="rgba(255,255,255,0.1)"
          />
          <YAxis
            tickLine={false}
            tick={{ fill: 'rgba(255,255,255,0.7)', fontSize: 12 }}
            stroke="rgba(255,255,255,0.1)"
            domain={[16, 30]}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'rgba(0,0,0,0.8)',
              border: '1px solid rgba(255,255,255,0.2)',
              borderRadius: '0.375rem',
              fontSize: '0.875rem',
              color: 'white'
            }}
          />
          <Area
            type="monotone"
            dataKey="temperature"
            stroke="rgba(255,255,255,0.8)"
            strokeWidth={2}
            fill="url(#temperatureGradient)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TemperatureChart;