import { useEffect, useRef } from 'react';

type WeatherSceneProps = {
  condition: string;
  isDay: boolean;
};

const WeatherScene = ({ condition, isDay }: WeatherSceneProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas size
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    window.addEventListener('resize', resize);
    resize();
    
    // Create particles based on weather condition
    const particles: Particle[] = [];
    const particleCount = getParticleCount(condition);
    
    for (let i = 0; i < particleCount; i++) {
      particles.push(createParticle(condition, isDay, canvas.width, canvas.height));
    }
    
    // Animation
    let animationId: number;
    
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach(particle => {
        // Update position
        particle.y += particle.speed;
        particle.x += particle.windSpeed;
        
        // Reset if off screen
        if (particle.y > canvas.height) {
          particle.y = -10;
          particle.x = Math.random() * canvas.width;
        }
        
        if (particle.x > canvas.width) {
          particle.x = 0;
        } else if (particle.x < 0) {
          particle.x = canvas.width;
        }
        
        // Draw particle
        ctx.beginPath();
        
        if (condition.includes('rain')) {
          ctx.moveTo(particle.x, particle.y);
          ctx.lineTo(particle.x + particle.windSpeed * 2, particle.y + particle.speed * 0.7);
          ctx.strokeStyle = particle.color;
          ctx.lineWidth = particle.size;
          ctx.stroke();
        } else if (condition.includes('snow')) {
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          ctx.fillStyle = particle.color;
          ctx.fill();
        } else if (condition.includes('cloud')) {
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          ctx.fillStyle = particle.color;
          ctx.fill();
        } else if (condition.includes('sun') || condition.includes('clear')) {
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          ctx.fillStyle = particle.color;
          ctx.globalAlpha = particle.opacity;
          ctx.fill();
          ctx.globalAlpha = 1;
        } else {
          // Default particles
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          ctx.fillStyle = particle.color;
          ctx.globalAlpha = particle.opacity;
          ctx.fill();
          ctx.globalAlpha = 1;
        }
      });
      
      animationId = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationId);
    };
  }, [condition, isDay]);
  
  return <canvas ref={canvasRef} className="absolute inset-0" />;
};

// Helper functions
interface Particle {
  x: number;
  y: number;
  size: number;
  speed: number;
  windSpeed: number;
  color: string;
  opacity: number;
}

function getParticleCount(condition: string): number {
  if (condition.includes('heavy rain')) return 200;
  if (condition.includes('rain')) return 100;
  if (condition.includes('snow')) return 150;
  if (condition.includes('cloud')) return 20;
  if (condition.includes('sun') || condition.includes('clear')) return 50;
  return 30; // default
}

function createParticle(condition: string, isDay: boolean, width: number, height: number): Particle {
  const baseParticle = {
    x: Math.random() * width,
    y: Math.random() * height,
    opacity: Math.random() * 0.5 + 0.3,
  };
  
  if (condition.includes('rain')) {
    return {
      ...baseParticle,
      size: Math.random() * 1 + 0.5,
      speed: Math.random() * 15 + 10,
      windSpeed: Math.random() * 2 - 1,
      color: 'rgba(196, 220, 255, 0.6)',
      opacity: 0.7,
    };
  } else if (condition.includes('snow')) {
    return {
      ...baseParticle,
      size: Math.random() * 3 + 1,
      speed: Math.random() * 2 + 1,
      windSpeed: Math.random() * 2 - 1,
      color: 'rgba(255, 255, 255, 0.8)',
      opacity: 0.8,
    };
  } else if (condition.includes('cloud')) {
    return {
      ...baseParticle,
      size: Math.random() * 50 + 30,
      speed: Math.random() * 0.2,
      windSpeed: Math.random() * 0.5,
      color: isDay ? 'rgba(255, 255, 255, 0.2)' : 'rgba(90, 90, 110, 0.2)',
      opacity: Math.random() * 0.2 + 0.1,
    };
  } else if (condition.includes('sun') || condition.includes('clear')) {
    return {
      ...baseParticle,
      size: Math.random() * 2 + 0.5,
      speed: Math.random() * 0.5 + 0.1,
      windSpeed: Math.random() * 0.5 - 0.25,
      color: isDay ? 'rgba(255, 255, 150, 0.6)' : 'rgba(150, 180, 255, 0.3)',
      opacity: Math.random() * 0.3 + 0.1,
    };
  } else {
    return {
      ...baseParticle,
      size: Math.random() * 3 + 1,
      speed: Math.random() * 1 + 0.5,
      windSpeed: Math.random() * 1 - 0.5,
      color: isDay ? 'rgba(255, 255, 255, 0.3)' : 'rgba(100, 100, 150, 0.3)',
      opacity: Math.random() * 0.3 + 0.1,
    };
  }
}

export default WeatherScene;