import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip
} from 'recharts';

interface TemperaturePeriodChartProps {
  type: 'pie' | 'bar';
}

const TemperaturePeriodChart = ({ type }: TemperaturePeriodChartProps) => {
  const pieData = [
    { name: 'Manhã (20.4°C)', value: 20.4, color: '#7DD3FC' },
    { name: 'Tarde (25.8°C)', value: 25.8, color: '#F472B6' },
    { name: 'Noite (19.1°C)', value: 19.1, color: '#818CF8' }
  ];

  const barData = [
    { name: 'Manhã', temperature: 20.4, color: '#7DD3FC' },
    { name: 'Tarde', temperature: 25.8, color: '#F472B6' },
    { name: 'Noite', temperature: 19.1, color: '#818CF8' }
  ];

  if (type === 'pie') {
    return (
      <div className="h-[300px]">
        <div className="mb-2 text-sm text-gray-500">
          São Paulo (15/06/2023)
        </div>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={pieData}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              paddingAngle={5}
              dataKey="value"
            >
              {pieData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </div>
    );
  }

  return (
    <div className="h-[300px]">
      <div className="mb-2 text-sm text-gray-500">
        Variação Térmica Diária
      </div>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={barData}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis
            dataKey="name"
            tickLine={false}
            tick={{ fill: '#6B7280', fontSize: 12 }}
          />
          <YAxis
            tickLine={false}
            tick={{ fill: '#6B7280', fontSize: 12 }}
            domain={[0, 30]}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #E5E7EB',
              borderRadius: '0.375rem',
              fontSize: '0.875rem'
            }}
          />
          <Bar dataKey="temperature">
            {barData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default TemperaturePeriodChart;