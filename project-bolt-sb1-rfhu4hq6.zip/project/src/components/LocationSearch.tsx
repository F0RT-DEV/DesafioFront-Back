import { useState, useEffect, useRef } from 'react';
import { Search, MapPin, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useWeatherStore } from '../store/weatherStore';

const LocationSearch = () => {
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const { setLocation } = useWeatherStore();
  
  // Focus input when search opens
  useEffect(() => {
    if (searchOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [searchOpen]);
  
  // Mock search function - in a real app, this would call a geocoding API
  const handleSearch = (term: string) => {
    setSearchTerm(term);
    
    if (term.length < 2) {
      setSearchResults([]);
      return;
    }
    
    // Simulate API call with mock cities
    const mockCities = [
      'São Paulo, Brasil',
      'Rio de Janeiro, Brasil',
      'Curitiba, Brasil',
      'Belo Horizonte, Brasil',
      'Salvador, Brasil',
      'Brasília, Brasil',
      'Fortaleza, Brasil',
      'Recife, Brasil',
      'Manaus, Brasil',
      'Porto Alegre, Brasil'
    ];
    
    const filteredResults = mockCities.filter(city => 
      city.toLowerCase().includes(term.toLowerCase())
    );
    
    setSearchResults(filteredResults);
  };
  
  const handleSelectLocation = (location: string) => {
    setLocation(location);
    setSearchTerm('');
    setSearchResults([]);
    setSearchOpen(false);
  };
  
  return (
    <div className="relative mb-6">
      <div 
        className={`flex items-center rounded-full bg-white/10 px-4 py-3 backdrop-blur-md transition-all duration-300 ${
          searchOpen ? 'ring-2 ring-white/30' : ''
        }`}
      >
        <Search 
          className={`h-5 w-5 transition-all duration-200 ${
            searchOpen ? 'text-white' : 'text-white/70'
          }`} 
        />
        
        <AnimatePresence>
          {!searchOpen ? (
            <motion.button
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="ml-3 flex-1 text-left text-sm text-white/70"
              onClick={() => setSearchOpen(true)}
            >
              Buscar local...
            </motion.button>
          ) : (
            <motion.input
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: '100%', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              ref={inputRef}
              type="text"
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Digite o nome da cidade..."
              className="ml-3 flex-1 bg-transparent text-sm text-white placeholder-white/50 outline-none"
            />
          )}
        </AnimatePresence>
        
        {searchOpen && (
          <button 
            onClick={() => {
              setSearchOpen(false);
              setSearchTerm('');
              setSearchResults([]);
            }}
            className="ml-2 text-white/70 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      
      {/* Search results dropdown */}
      <AnimatePresence>
        {searchOpen && searchResults.length > 0 && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="absolute left-0 right-0 top-full z-10 mt-1 overflow-hidden rounded-lg bg-black/30 backdrop-blur-md"
          >
            <ul className="max-h-60 overflow-y-auto py-1">
              {searchResults.map((result, index) => (
                <li key={index}>
                  <button
                    onClick={() => handleSelectLocation(result)}
                    className="flex w-full items-center px-4 py-2 text-left text-sm text-white/80 transition-colors hover:bg-white/10 hover:text-white"
                  >
                    <MapPin className="mr-2 h-4 w-4 text-blue-300" />
                    {result}
                  </button>
                </li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default LocationSearch;