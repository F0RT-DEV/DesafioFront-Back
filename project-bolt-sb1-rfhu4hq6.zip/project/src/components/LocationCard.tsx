import { Eye } from 'lucide-react';

interface LocationCardProps {
  city: string;
  state: string;
  temp: number;
  maxTemp: number;
  minTemp: number;
  measurementCount: number;
  status: 'normal' | 'warning' | 'alert';
}

const LocationCard = ({
  city,
  state,
  temp,
  maxTemp,
  minTemp,
  measurementCount,
  status
}: LocationCardProps) => {
  const statusColors = {
    normal: 'bg-green-500',
    warning: 'bg-yellow-500',
    alert: 'bg-red-500'
  };

  return (
    <div className="relative overflow-hidden rounded-lg border bg-white p-4">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center space-x-2">
            <div className={`h-2 w-2 rounded-full ${statusColors[status]}`} />
            <h3 className="font-medium text-gray-900">
              {city} - {state}
            </h3>
          </div>
          
          <div className="mt-4 flex items-baseline">
            <span className="text-4xl font-bold text-gray-900">{temp}°C</span>
          </div>
          
          <div className="mt-1 text-sm text-gray-500">
            Máx: {maxTemp}°C | Mín: {minTemp}°C
          </div>
          
          <div className="mt-4 flex items-center text-sm text-gray-500">
            📊 {measurementCount} medições hoje
          </div>
        </div>
        
        <button className="rounded-md bg-gray-50 p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-500">
          <Eye className="h-5 w-5" />
        </button>
      </div>
    </div>
  );
};

export default LocationCard;