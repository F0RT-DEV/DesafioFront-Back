import { useState, useEffect } from 'react';
import { Wind, Droplets, Sunrise, Sunset, ThermometerSun } from 'lucide-react';
import { motion } from 'framer-motion';
import { formatTime } from '../utils/dateUtils';
import { WeatherData } from '../types/weather';

type WeatherDetailsProps = {
  weather: WeatherData;
};

const WeatherDetails = ({ weather }: WeatherDetailsProps) => {
  const [tempAnimation, setTempAnimation] = useState(false);
  
  useEffect(() => {
    setTempAnimation(true);
    const timer = setTimeout(() => setTempAnimation(false), 1000);
    return () => clearTimeout(timer);
  }, [weather.temp]);

  const getTimeOfDayGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Bom dia';
    if (hour < 18) return 'Boa tarde';
    return 'Boa noite';
  };

  return (
    <div className="mx-auto max-w-3xl">
      <div className="mb-8 text-center">
        <div className="mb-1 text-sm font-medium tracking-wider text-white/70">
          {getTimeOfDayGreeting()}
        </div>
        <h2 className="mb-2 text-2xl font-bold text-white md:text-3xl">
          {weather.location}
        </h2>
        <div className="text-sm text-white/70">
          {new Date().toLocaleDateString('pt-BR', { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative mb-10 rounded-3xl bg-white/10 p-6 backdrop-blur-md md:p-8"
      >
        <div className="flex flex-col items-center space-y-6 md:flex-row md:items-stretch md:space-x-8 md:space-y-0">
          {/* Weather icon and temperature */}
          <div className="flex flex-1 flex-col items-center text-center md:items-start md:text-left">
            <div className="weather-icon-container mb-3 flex h-24 w-24 items-center justify-center rounded-full bg-white/20 backdrop-blur-lg">
              <img 
                src={`/weather-icons/${weather.icon}.svg`} 
                alt={weather.condition}
                className="h-16 w-16 object-contain"
              />
            </div>
            
            <h3 className="text-lg font-medium text-white/80">
              {weather.condition}
            </h3>
            
            <div className="mt-2 flex items-end">
              <motion.span
                className="text-6xl font-bold text-white"
                animate={tempAnimation ? { scale: [1, 1.1, 1] } : {}}
                transition={{ duration: 0.4 }}
              >
                {Math.round(weather.temp)}
              </motion.span>
              <span className="ml-1 text-3xl font-light text-white/70">°C</span>
            </div>
            
            <div className="mt-2 flex items-center space-x-3 text-sm text-white/60">
              <div className="flex items-center">
                <ThermometerSun className="mr-1 h-3 w-3" />
                <span>Máx: {Math.round(weather.maxTemp)}°</span>
              </div>
              <div>|</div>
              <div className="flex items-center">
                <ThermometerSun className="mr-1 h-3 w-3" />
                <span>Mín: {Math.round(weather.minTemp)}°</span>
              </div>
            </div>
          </div>
          
          {/* Weather details */}
          <div className="flex flex-1 flex-col justify-between">
            <div className="grid grid-cols-2 gap-4">
              <DetailCard 
                icon={<Wind className="h-5 w-5 text-blue-300" />}
                title="Vento"
                value={`${weather.windSpeed} km/h`}
                detail={`${weather.windDirection}`}
              />
              
              <DetailCard 
                icon={<Droplets className="h-5 w-5 text-blue-300" />}
                title="Umidade"
                value={`${weather.humidity}%`}
                detail="Índice de umidade"
              />
              
              <DetailCard 
                icon={<Sunrise className="h-5 w-5 text-yellow-300" />}
                title="Nascer do sol"
                value={formatTime(weather.sunrise)}
                detail="Hoje"
              />
              
              <DetailCard 
                icon={<Sunset className="h-5 w-5 text-orange-300" />}
                title="Pôr do sol"
                value={formatTime(weather.sunset)}
                detail="Hoje"
              />
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute -bottom-2 left-8 h-4 w-20 rounded-full bg-white/5"></div>
        <div className="absolute -right-2 top-10 h-16 w-4 rounded-full bg-white/5"></div>
      </motion.div>
    </div>
  );
};

type DetailCardProps = {
  icon: React.ReactNode;
  title: string;
  value: string;
  detail: string;
};

const DetailCard = ({ icon, title, value, detail }: DetailCardProps) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.4, delay: 0.2 }}
    className="flex flex-col rounded-xl bg-white/5 p-3 backdrop-blur-sm"
  >
    <div className="mb-1 flex items-center space-x-2">
      {icon}
      <span className="text-xs font-medium text-white/70">{title}</span>
    </div>
    <div className="mt-auto">
      <div className="text-base font-semibold text-white">{value}</div>
      <div className="text-xs text-white/50">{detail}</div>
    </div>
  </motion.div>
);

export default WeatherDetails;