import { useState, useEffect } from 'react';
import Header from './components/Header';
import WeatherScene from './components/WeatherScene';
import Forecast from './components/Forecast';
import WeatherDetails from './components/WeatherDetails';
import LocationSearch from './components/LocationSearch';
import TemperatureChart from './components/TemperatureChart';
import { useWeatherStore } from './store/weatherStore';
import { fetchWeatherData } from './api/weatherApi';
import { weatherSounds } from './utils/audioUtils';

function App() {
  const [loading, setLoading] = useState(true);
  const [audioInitialized, setAudioInitialized] = useState(false);
  const { currentWeather, setCurrentWeather, setForecast, location } = useWeatherStore();

  useEffect(() => {
    if (location) {
      setLoading(true);
      fetchWeatherData(location)
        .then(data => {
          setCurrentWeather(data.current);
          setForecast(data.forecast);
          
          if (!audioInitialized && data.current) {
            weatherSounds.initialize(data.current.condition);
            setAudioInitialized(true);
          }
          
          setTimeout(() => setLoading(false), 800);
        })
        .catch(err => {
          console.error('Error fetching weather data:', err);
          setLoading(false);
        });
    }
  }, [location, setCurrentWeather, setForecast, audioInitialized]);

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-gradient-to-b from-indigo-900 to-purple-900">
      <div 
        className="absolute inset-0 bg-gradient-to-br transition-colors duration-1000"
        style={{
          opacity: 0.8,
          backgroundImage: currentWeather 
            ? `radial-gradient(circle at 50% 50%, 
                ${currentWeather.isDay ? '#4361EE' : '#3A0CA3'}, 
                ${currentWeather.isDay ? '#3A0CA3' : '#240046'})`
            : 'radial-gradient(circle at 50% 50%, #4361EE, #3A0CA3)',
        }}
      />
      
      <div className="absolute inset-0 z-0 overflow-hidden opacity-30">
        {currentWeather && <WeatherScene condition={currentWeather.condition} isDay={currentWeather.isDay} />}
      </div>
      
      <div className="relative z-10 flex h-full flex-col">
        <Header />
        
        <main className="flex-1 overflow-y-auto overflow-x-hidden px-6 pb-8 pt-4">
          <LocationSearch />
          
          {loading ? (
            <div className="flex h-[60vh] items-center justify-center">
              <div className="h-16 w-16 animate-spin rounded-full border-b-2 border-t-2 border-white"></div>
            </div>
          ) : (
            <>
              {currentWeather && (
                <div className="space-y-8">
                  <WeatherDetails weather={currentWeather} />
                  <div className="rounded-xl bg-white/10 p-6 backdrop-blur-md">
                    <TemperatureChart />
                  </div>
                  <Forecast />
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
}

export default App;