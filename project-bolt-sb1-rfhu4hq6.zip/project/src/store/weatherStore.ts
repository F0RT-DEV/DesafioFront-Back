import { create } from 'zustand';
import { WeatherData, ForecastData } from '../types/weather';

interface WeatherState {
  location: string | null;
  currentWeather: WeatherData | null;
  forecast: ForecastData | null;
  setLocation: (location: string) => void;
  setCurrentWeather: (weather: WeatherData) => void;
  setForecast: (forecast: ForecastData) => void;
}

export const useWeatherStore = create<WeatherState>((set) => ({
  location: 'São Paulo, Brasil', // Default location
  currentWeather: null,
  forecast: null,
  setLocation: (location) => set({ location }),
  setCurrentWeather: (weather) => set({ currentWeather: weather }),
  setForecast: (forecast) => set({ forecast }),
}));