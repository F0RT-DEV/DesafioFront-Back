import { WeatherData, ForecastData } from '../types/weather';

// Mock API response - in a real app, this would fetch from a real weather API
export const fetchWeatherData = async (location: string): Promise<{ current: WeatherData, forecast: ForecastData }> => {
  console.log(`Fetching weather data for ${location}...`);
  
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 800));
  
  // Generate random weather data for demonstration
  const isDay = new Date().getHours() > 6 && new Date().getHours() < 18;
  const temp = Math.random() * 15 + 15; // Random temp between 15-30°C
  const conditions = [
    'Ensolarado', 'Parcialmente nublado', 'Nublado', 
    'Chuva leve', 'Chuva moderada', 'Trovoadas'
  ];
  const conditionIndex = Math.floor(Math.random() * conditions.length);
  const condition = conditions[conditionIndex];
  
  // Icons mapping
  const iconMap: {[key: string]: string} = {
    'Ensolarado': 'sun',
    'Parcialmente nublado': 'cloud-sun',
    'Nublado': 'cloud',
    'Chuva leve': 'cloud-drizzle',
    'Chuva moderada': 'cloud-rain',
    'Trovoadas': 'cloud-lightning'
  };
  
  // Sunrise and sunset times
  const now = new Date();
  const sunrise = new Date(now);
  sunrise.setHours(6, 0, 0, 0);
  const sunset = new Date(now);
  sunset.setHours(18, 0, 0, 0);
  
  // Current weather
  const currentWeather: WeatherData = {
    location,
    temp,
    maxTemp: temp + Math.random() * 5,
    minTemp: temp - Math.random() * 5,
    feelsLike: temp - Math.random() * 2,
    humidity: Math.random() * 50 + 30, // 30-80%
    windSpeed: Math.random() * 20 + 5, // 5-25 km/h
    windDirection: ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.floor(Math.random() * 8)],
    pressure: Math.random() * 20 + 1000, // 1000-1020 hPa
    visibility: Math.random() * 5 + 5, // 5-10 km
    uvIndex: Math.floor(Math.random() * 11), // 0-10
    condition,
    icon: iconMap[condition] || 'sun',
    isDay,
    sunrise: sunrise.toISOString(),
    sunset: sunset.toISOString()
  };
  
  // Generate hourly forecast
  const hourlyForecast: ForecastData['hourly'] = [];
  const now2 = new Date();
  
  for (let i = 0; i < 24; i++) {
    const forecastTime = new Date(now2);
    forecastTime.setHours(forecastTime.getHours() + i);
    
    const isForecastDay = forecastTime.getHours() > 6 && forecastTime.getHours() < 18;
    const hourTemp = temp + (Math.random() * 10 - 5) * (isForecastDay ? 1 : 0.5);
    const hourConditionIndex = Math.min(
      Math.max(
        conditionIndex + Math.floor(Math.random() * 3 - 1),
        0
      ),
      conditions.length - 1
    );
    
    hourlyForecast.push({
      time: forecastTime.toISOString(),
      temp: hourTemp,
      condition: conditions[hourConditionIndex],
      icon: iconMap[conditions[hourConditionIndex]] || 'sun',
      windSpeed: Math.random() * 20 + 5,
      rainChance: conditions[hourConditionIndex].includes('Chuva') ? Math.random() * 80 + 20 : Math.random() * 20
    });
  }
  
  // Generate daily forecast
  const dailyForecast: ForecastData['daily'] = [];
  const today = new Date();
  
  for (let i = 0; i < 7; i++) {
    const forecastDate = new Date(today);
    forecastDate.setDate(forecastDate.getDate() + i);
    
    const dayConditionIndex = Math.min(
      Math.max(
        conditionIndex + Math.floor(Math.random() * 5 - 2),
        0
      ),
      conditions.length - 1
    );
    
    const dayMaxTemp = temp + Math.random() * 10 - 2;
    
    dailyForecast.push({
      date: forecastDate.toISOString(),
      maxTemp: dayMaxTemp,
      minTemp: dayMaxTemp - Math.random() * 10 - 2,
      condition: conditions[dayConditionIndex],
      icon: iconMap[conditions[dayConditionIndex]] || 'sun',
      windSpeed: Math.random() * 20 + 5,
      rainChance: conditions[dayConditionIndex].includes('Chuva') ? Math.random() * 80 + 20 : Math.random() * 20
    });
  }
  
  return {
    current: currentWeather,
    forecast: {
      hourly: hourlyForecast,
      daily: dailyForecast
    }
  };
};